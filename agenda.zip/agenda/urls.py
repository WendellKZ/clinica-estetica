from django.urls import path

from . import views

app_name = "agenda"

urlpatterns = [
    # visões específicas
    path("dia/", views.agenda_dia, name="agenda_dia"),
    path("novo/", views.agendamento_novo, name="agenda_novo"),

    # navegação semanal por offset (aceita valores negativos: -1, 1, etc.)
    # IMPORTANTE: precisa ficar ANTES do "" para permitir reverse com offset
    path("<str:offset>/", views.agenda_semana, name="agenda_lista"),

    # padrão (semana atual)
    path("", views.agenda_semana, name="agenda_lista"),
]
