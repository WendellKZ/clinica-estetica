from __future__ import annotations

from datetime import timedelta
from decimal import Decimal

from django.apps import apps
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.utils import timezone


def _get_model(app_label: str, model_name: str):
    try:
        return apps.get_model(app_label, model_name)
    except Exception:
        return None


def _get_agendamento_model():
    return _get_model("agenda", "Agendamento")


def _week_bounds(base_date):
    weekday = base_date.weekday()  # 0=Mon
    start = base_date - timedelta(days=weekday)
    end = start + timedelta(days=6)
    return start, end


def _sync_servicos(master_model, target_model):
    """Copia/atualiza Serviços do model 'master' para o model que o Agendamento usa.

    Isso resolve o cenário onde:
    - O cadastro/gestão de serviços está em `servicos.Servico`
    - O Agendamento referencia `agenda.Servico` (ou outro model diferente)

    A sincronização é por nome (campo 'nome').
    """
    if not master_model or not target_model:
        return

    # Campos prováveis
    master_qs = master_model.objects.all()
    try:
        master_qs = master_qs.order_by("nome")
    except Exception:
        pass

    for s in master_qs:
        nome = getattr(s, "nome", None) or str(s)
        # Copia campos somente se EXISTIREM no model destino (evita FieldError)
        def _has_field(model, field_name: str) -> bool:
            try:
                model._meta.get_field(field_name)
                return True
            except Exception:
                return hasattr(model, field_name)

        defaults = {}
        # Copia campos "iguais" quando existem nos dois modelos
        for f in ["duracao", "duracao_minutos", "preco_padrao", "custo_padrao", "ativo", "status"]:
            if hasattr(s, f) and _has_field(target_model, f):
                defaults[f] = getattr(s, f)

        # Mapeia campos equivalentes quando o modelo alvo usa nomes diferentes
        # (ex.: agenda.Servico geralmente usa preco/custo, enquanto servicos.Servico usa *_padrao)
        if _has_field(target_model, "preco") and "preco" not in defaults:
            val = None
            for cand in ("preco", "preco_padrao"):
                if hasattr(s, cand):
                    val = getattr(s, cand)
                    if val not in (None, ""):
                        break
            defaults["preco"] = val if val not in (None, "") else Decimal("0.00")

        if _has_field(target_model, "custo") and "custo" not in defaults:
            val = None
            for cand in ("custo", "custo_padrao"):
                if hasattr(s, cand):
                    val = getattr(s, cand)
                    if val not in (None, ""):
                        break
            defaults["custo"] = val if val not in (None, "") else Decimal("0.00")

        if _has_field(target_model, "ativo") and "ativo" not in defaults:
            defaults["ativo"] = bool(getattr(s, "ativo", True))

        # Alguns bancos antigos podem não ter todos os campos: se der erro, cria só pelo nome.
        try:
            obj, created = target_model.objects.get_or_create(nome=nome, defaults=defaults)
        except Exception:
            obj, created = target_model.objects.get_or_create(nome=nome)

        # Atualiza campos existentes no target
        changed = False
        for k, v in defaults.items():
            if hasattr(obj, k) and getattr(obj, k) != v:
                setattr(obj, k, v)
                changed = True
        if changed:
            try:
                obj.save()
            except Exception:
                pass


@login_required
def agenda_semana(request, offset: int = 0):
    """Página principal /agenda/"""
    try:
        offset = int(request.GET.get("offset", offset or 0))
    except Exception:
        offset = 0

    today = timezone.localdate()
    base = today + timedelta(weeks=offset)
    semana_inicio, semana_fim = _week_bounds(base)

    Agendamento = _get_agendamento_model()
    agendamentos = []
    if Agendamento:
        qs = Agendamento.objects.all()
        if hasattr(Agendamento, "inicio"):
            start_dt = timezone.make_aware(timezone.datetime.combine(semana_inicio, timezone.datetime.min.time()))
            end_dt = timezone.make_aware(timezone.datetime.combine(semana_fim, timezone.datetime.max.time()))
            qs = qs.filter(inicio__range=(start_dt, end_dt)).order_by("inicio")
        elif hasattr(Agendamento, "data"):
            qs = qs.filter(data__range=(semana_inicio, semana_fim)).order_by("data")
        agendamentos = qs

    return render(
        request,
        "agenda/agenda.html",
        {
            "agendamentos": agendamentos,
            "semana_inicio": semana_inicio,
            "semana_fim": semana_fim,
            "offset": offset,
        },
    )


# compatibilidade
agenda_lista = agenda_semana


def _configure_agendamento_form(form, request):
    """Configura widgets/initial do form para evitar 'nada acontece' no submit.

    - Força datetime-local (melhor UX e evita formato inválido)
    - Preenche início com data/hora atual no GET
    - Deixa o 'fim' opcional (normalmente calculado automaticamente)
    """
    from django.utils import timezone

    if not hasattr(form, 'fields'):
        return

    # datetime-local friendly
    for fname in ('inicio', 'fim'):
        if fname in form.fields:
            try:
                form.fields[fname].widget.attrs.setdefault('type', 'datetime-local')
                form.fields[fname].widget.attrs.setdefault('step', '60')  # minuto
            except Exception:
                pass

    # 'fim' normalmente é calculado, então não travamos o submit
    if 'fim' in form.fields:
        try:
            form.fields['fim'].required = False
        except Exception:
            pass

    # inicial do início (GET)
    if request.method == 'GET' and 'inicio' in form.fields:
        try:
            now = timezone.localtime(timezone.now()).replace(second=0, microsecond=0)
            # para datetime-local, o value precisa ser YYYY-MM-DDTHH:MM
            form.initial.setdefault('inicio', now.strftime('%Y-%m-%dT%H:%M'))
        except Exception:
            pass


@login_required
def agenda_novo(request):
    """Criar um novo agendamento (com serviços corretos no dropdown).

    Obs.: Se o formulário não submete, quase sempre é campo datetime em formato inválido
    ou campo obrigatório não preenchido. Aqui a gente força datetime-local + mostra erros.
    """
    from .forms import AgendamentoForm

    # master de serviços (onde o admin cadastra)
    ServicoMaster = _get_model('servicos', 'Servico') or _get_model('core', 'Servico')
    Cliente = _get_model('clientes', 'Cliente') or _get_model('core', 'Cliente')

    profissionais_qs = User.objects.filter(is_active=True)
    try:
        profissionais_qs = profissionais_qs.filter(groups__name__iexact='Profissional')
    except Exception:
        pass
    try:
        profissionais_qs = profissionais_qs.order_by('username')
    except Exception:
        pass

    form = AgendamentoForm(request.POST or None)
    _configure_agendamento_form(form, request)

    # Descobre qual model o campo 'servico' realmente usa (evita mismatch Servico x Servico)
    target_servico_model = None
    if hasattr(form, 'fields') and 'servico' in form.fields:
        try:
            target_servico_model = form.fields['servico'].queryset.model
        except Exception:
            target_servico_model = None

    # Se o Agendamento usa um Servico diferente do master, sincroniza
    if ServicoMaster and target_servico_model and target_servico_model != ServicoMaster:
        _sync_servicos(ServicoMaster, target_servico_model)

    # Queryset final para o dropdown (sempre baseado no model do campo)
    servicos_qs = target_servico_model.objects.all() if target_servico_model else []
    # tenta filtros comuns
    for flag in ('ativo', 'is_active'):
        try:
            servicos_qs = servicos_qs.filter(**{flag: True})
            break
        except Exception:
            continue
    try:
        servicos_qs = servicos_qs.order_by('nome')
    except Exception:
        pass

    # Ajusta querysets do form
    if hasattr(form, 'fields'):
        if 'servico' in form.fields and target_servico_model:
            try:
                form.fields['servico'].queryset = servicos_qs
            except Exception:
                pass

        if 'profissional' in form.fields:
            try:
                form.fields['profissional'].queryset = profissionais_qs
            except Exception:
                pass

        if 'cliente' in form.fields and Cliente:
            try:
                form.fields['cliente'].queryset = Cliente.objects.all().order_by('nome')
            except Exception:
                pass

    if request.method == 'POST':
        if form.is_valid():
            form.save()
            messages.success(request, 'Agendamento criado com sucesso.')
            return redirect('agenda_lista')
        else:
            # Garante que o usuário veja o motivo
            messages.error(request, 'Não consegui salvar. Confira os campos destacados (início/data costuma ser o principal).')

    return render(request, 'agenda/agenda_novo.html', {
        'form': form,
        'servicos': servicos_qs,
        'profissionais': profissionais_qs,
    })
